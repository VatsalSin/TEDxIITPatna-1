<?php include("include/header.php"); ?>


	<div class="container" style="padding:2%;">

	   <!-- <h3 >  <center> Chairman </center> </h3>
	    <div class="row">
		    <div class="col-md-12 col-sm-12 col-xs-12" >
		    	<center>
			        <img  src="images/advisor/director.jpg" alt="pic" class="thumbnail" style="width:150px;height:150px">
		    		<p class="text-center">Prof. Pushpak Bhattacharya  <span class="organiser_description">&nbsp;&nbsp;&nbsp;<br>Director, IIT Patna</span>
			        <!--a href="mailto:dinesh@iitp.ac.in" target="_top" style="display:block;"> dinesh@iitp.ac.in </a--> </p>
		    	</center>
		    </div>
	    </div>-->


	    <h3 >  <center> Faculty-in-charge </center> </h3>
	    <div class="row">
		    <div class="col-md-12 col-sm-12 col-xs-12" >
		    	<center>
			        <img  src="images/advisor/pic_tedxiitp.jpg" alt="pic" class="thumbnail" style="width:150px;height:150px">
		    		<p class="text-center">Dr. Dinesh Kumar Kotnees  <span class="organiser_description">&nbsp;&nbsp;&nbsp;<br>Faculty-in-charge</span>
			        <!--<a href="mailto:dinesh@iitp.ac.in" target="_top" style="display:block;"> dinesh@iitp.ac.in </a>--> </p>
		    	</center>
		    </div>
	    </div>
	    <hr/>

	    <h3 >  <center> Student Organizers </center> </h3>
	    <div class="row">
		    <div class="col-md-4 col-sm-12 col-xs-12" >
		    	<center>
			        <img  src="images/organizer/p01.jpg" alt="Curator" class="thumbnail" style="width:150px;height:150px">
		    		<p class="text-center">Mayank Garg <br/> <span class="organiser_description">Curator</span> </p>
		    	</center>
		    </div>
		    <div class="col-md-4 col-sm-6 col-xs-12" >
		    	<center>
			        <img  src="images/organizer/ram.jpg" alt="member" class="thumbnail" style="width:150px;height:150px">
		    		<p class="text-center">Ram Agarwal <br/>  <span class="organiser_description"> Executive Director</span>   </p>
		    	</center>
		    </div>
		    <div class="col-md-4 col-sm-6 col-xs-12" >
		    	<center>
			        <img  src="images/organizer/p03.jpg" alt="member" class="thumbnail" style="width:150px;height:150px">
		    		<p class="text-center">Varun Sunil Gokhale </br> <span class="organiser_description">Communication,<br> Editorial and Marketing Manager </span> </p>
		    	</center>
		    </div>
		</div>

		<div class="row">
		    
		    <div class="col-md-4 col-sm-6 col-xs-12" >
		    	<center>
			        <img  src="images/organizer/p05.jpg" alt="member" class="thumbnail" style="width:150px;height:150px">
		    		<p class="text-center">Shashwat Gupta <br/>  <span class="organiser_description"> Designer </span>   </p>
		    	</center>
		    </div>
		    <div class="col-md-4 col-sm-6 col-xs-12" >
		    	<center>
			        <img  src="images/organizer/ritik.jpg" alt="member" class="thumbnail" style="width:150px;height:150px">
		    		<p class="text-center">Ritik Prasad Mathur </br> <span class="organiser_description">Web Developer </span> </p>
		    	</center>
		    </div>
		    <div class="col-md-4 col-sm-6 col-xs-12" >
		    	<center>
			        <img  src="images/organizer/vgarg.jpg" alt="member" class="thumbnail" style="width:150px;height:150px">
		    		<p class="text-center">Varun Garg<br/>  <span class="organiser_description">Marketing Manager </span>   </p>
		    	</center>
		    </div>
		</div>
		
		<div class="row">
		
		    <div class="col-md-4 col-sm-6 col-xs-12" >
		    	<center>
			        <img  src="images/organizer/p08.jpg" alt="member" class="thumbnail" style="width:150px;height:150px">
		    		<p class="text-center">Ankit Tripathi <br/>  <span class="organiser_description"> Web Developer </span>   </p>
		    	</center>
		    </div>
		    <div class="col-md-4 col-sm-12 col-xs-12" >
		    	<center>
			        <img  src="images/organizer/p07.jpg" alt="member" class="thumbnail" style="width:150px;height:150px">
		    		<p class="text-center"> Rajeev Verma <br/> <span class="organiser_description"> Editorial Manager </span> </p>
		    	</center>
		    </div>
		     <div class="col-md-4 col-sm-12 col-xs-12" >
		    	<center>
			        <img  src="images/organizer/p07_.jpg" alt="member" class="thumbnail" style="width:150px;height:150px">
		    		<p class="text-center"> Aditya Jhalani <br/> <span class="organiser_description"> Editorial Manager </span> </p>
		    	</center>
		    </div>
		    		    
		    
		</div>

		<div class="row">
		<div class="col-md-4 col-sm-6 col-xs-12" >
		    	<center>
			        <img  src="images/organizer/p06.jpg" alt="member" class="thumbnail" style="width:150px;height:150px">
		    		<p class="text-center">Naman Rungta </br> <span class="organiser_description"> Event Manager </span> </p>
		    	</center>
		    </div>
		    <div class="col-md-4 col-sm-12 col-xs-12" >
		    	<center>
			        <img  src="images/organizer/p10.jpg" alt="member" class="thumbnail" style="width:150px;height:150px">
		    		<p class="text-center">Bitthal Saraf <br/> <span class="organiser_description"> Logistics and Event Manager </span> </p>
		    	</center>
		    </div>
		    <div class="col-md-4 col-sm-12 col-xs-12" >
		    	<center>
			        <img  src="images/organizer/p04.jpg" alt="member" class="thumbnail" style="width:150px;height:150px">
		    		<p class="text-center">Bhavit Sharma  <br/> <span class="organiser_description">Video and Production Lead</span> </p>
		    	</center>
		    </div>
		    
		</div>
		
		<div class="row">
			<div class="col-md-4 col-sm-6 col-xs-12 col-offset-md-4" >
		    	<center>
			        <img  src="images/organizer/p11.jpg" alt="member" class="thumbnail" style="width:150px;height:150px">
		    		<p class="text-center">Tameeesh Biswas </br> <span class="organiser_description">Web Developer </span> </p>
		    	</center>
		    </div>
		</div>

	</div>


<?php include("include/footer.php"); ?>