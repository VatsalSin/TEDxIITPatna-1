<?php ?>
		

		<!-- Footer -->
			<section id="footer">
				<div class="inner">
					<div class="copyright">
						<p><center> This independent TEDx event is operated under license from TED. </center></p>
					</div>
				</div>
			</section>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			

	</body>
</html>