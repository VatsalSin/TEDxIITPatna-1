<?php include("include/header.php"); ?>
<center>

	<div class="container" style="padding:2%;">
	    <h2>Sponsors</h2>
	    <hr/>

	    <h3 >  <center> </center> </h3>
	    <div class="row">

		    <div class="col-xs-12  " >
		    	<center>
			        <img  src="images/spons/maurya_gold.png" alt="Hotel Maurya" class="thumbnail" style="height:150px">
		    		<p class="text-center">Hotel Maurya</span>
		    	</center>
		    </div>
		    
		</div>
	    <div class="row">

		    <div class="col-xs-12" >
		    	<center>
			        <img  src="images/spons/AntonPaar_Silver.jpg" alt="AntonPaar" class="thumbnail" style="height:150px;width:55%;">
		    		<p class="text-center">AntonPaar</span></p>
		    	</center>
		    </div>
	    </div>
		
		<div class="row">
		   
		    <div class="col-xs-12" >
		    	<center>
			        <img  src="images/spons/GatanInc_Silver.png" alt="Gatan inc." class="thumbnail" style="height:150px">
		    		<p class="text-center">Gatan inc. </span></p>
		    	</center>
		    </div>
		    
		</div>
		
		<div class="row">
		   
		    <div class="col-xs-12  " >
		    	<center>
			        <img  src="images/spons/zwick_roell_logo_bronze.png" alt="Zwick Roell" class="thumbnail" style="height:150px; width:55%;">
		    		<p class="text-center">Zwick Roell </span></p>
		    	</center>
		    </div>
		    
		</div>
		
		<div class="row">
		   
		    <div class="col-xs-12  " >
		    	<center>
			        <img  src="images/spons/elsevier_logo_bronze.png" alt="Elsevier" class="thumbnail" style="height:150px">
		    		<p class="text-center"> Elsevier </span></p>
		    	</center>
		    </div>
		    
		</div>
		<p></p>

		
		

	</div>

</center>
<?php include("include/footer.php"); ?>