<?php include("include/header.php"); ?>


	<div class="container" style="padding:2%;">
	    <h2><center>Board of Advisors</center></h2>
	    <hr/>

	    <h3 >  <center> Faculty Advisors </center> </h3>
	    <div class="row">
		    <div class="col-md-4 col-sm-12 col-xs-12" >
		    	<center>
			        <img  src="images/advisor/p01.jpg" alt="pic" class="thumbnail" style="width:150px;height:150px">
		    		<p class="text-center">Dr. Dinesh Kumar Kotnees  <span >&nbsp;&nbsp;&nbsp;<br>(Faculty-in-charge)</span>
			        <a href="mailto:dinesh@iitp.ac.in" target="_top" style="display:block;"> dinesh@iitp.ac.in </a> </p>
		    	</center>
		    </div>
		    <div class="col-md-4 col-sm-6 col-xs-12" >
		    	<center>
			        <img  src="images/advisor/p02.jpg" alt="member" class="thumbnail" style="width:150px;height:150px">
		    		<p class="text-center">Dr. Akhilendra Singh
			        	<a href="mailto:akhil@iitp.ac.in" target="_top" style="display:block;"> akhil@iitp.ac.in </a> 
			        </p>
		    	</center>
		    </div>
		    <div class="col-md-4 col-sm-6 col-xs-12" >
		    	<center>
			        <img  src="images/advisor/p03.jpg" alt="member" class="thumbnail" style="width:150px;height:150px">
		    		<p class="text-center">Dr. Yatendra Kumar Singh  
			        	<a href="mailto:yatendra@iitp.ac.in" target="_top" style="display:block;"> yatendra@iitp.ac.in </a> 
			    	</p>
		    	</center>
		    </div>
		</div>

		<div class="row">
		    <div class="col-md-4 col-sm-12 col-xs-12" >
		    	<center>
			        <img  src="images/advisor/p04.jpg" alt="member" class="thumbnail" style="width:150px;height:150px">
		    		<p class="text-center">Dr. Asif Ekbal 
			        	<a href="mailto:asif@iitp.ac.in" target="_top" style="display:block;"> asif@iitp.ac.in </a> 
			        </p>
		    	</center>
		    </div>
		    <div class="col-md-4 col-sm-6 col-xs-12" >
		    	<center>
			        <img  src="images/advisor/p05.jpg" alt="member" class="thumbnail" style="width:150px;height:150px">
		    		<p class="text-center">Dr. Sriparna Saha
			        	<a href="mailto:sriparna@iitp.ac.in" target="_top" style="display:block;"> sriparna@iitp.ac.in </a> 
			        </p>
		    	</center>
		    </div>
		    <div class="col-md-4 col-sm-6 col-xs-12" >
		    	<center>
			        <img  src="images/advisor/p06.jpg" alt="member" class="thumbnail" style="width:150px;height:150px">
		    		<p class="text-center">Dr. Anup Kumar Keshri
			        	<a href="mailto:anup@iitp.ac.in" target="_top" style="display:block;"> anup@iitp.ac.in </a> 
			        </p>
		    	</center>
		    </div>
		</div>
		<p></p>

		
		

	</div>


<?php include("include/footer.php"); ?>